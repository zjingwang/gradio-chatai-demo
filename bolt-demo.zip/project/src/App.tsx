import { useState, useCallback, useRef } from 'react';
import { PanelLeftOpen, SquarePen } from 'lucide-react';
import Sidebar from '@/components/Sidebar';
import WelcomeScreen from '@/components/WelcomeScreen';
import MessageList from '@/components/MessageList';
import ChatInput from '@/components/ChatInput';
import type { ChatThread, ChatMessage } from '@/types';

const SAMPLE_REPLIES = [
  `Great question! Here's a structured approach:

1. **Define the goal clearly** — Write down exactly what you want to achieve so every decision can be measured against it.

2. **Break it into smaller steps** — Large tasks feel overwhelming. Divide them into manageable pieces and tackle one at a time.

3. **Iterate and gather feedback** — Don't wait for perfection. Ship a rough version, collect feedback, and improve.

Would you like me to go deeper on any of these steps?`,
  `Here's what I'd recommend:

Start by understanding the problem space thoroughly. Many issues arise from assumptions that don't hold up under scrutiny. Once you have a solid grasp, you can outline options, weigh trade-offs, and pick the path that best fits your constraints.

Let me know if you'd like a more detailed breakdown!`,
  `Absolutely — here's a concise answer:

The key is consistency. Small, deliberate actions compound over time into significant results. Focus on building a sustainable rhythm rather than chasing quick wins.

Feel free to ask follow-up questions if anything needs clarification.`,
];

function uid(): string {
  return Math.random().toString(36).slice(2) + Date.now().toString(36);
}

export default function App() {
  const [threads, setThreads] = useState<ChatThread[]>([]);
  const [activeThreadId, setActiveThreadId] = useState<string | null>(null);
  const [input, setInput] = useState('');
  const [thinking, setThinking] = useState(false);
  const [thinkingStep, setThinkingStep] = useState(0);
  const [deepThink, setDeepThink] = useState(false);
  const [searchEnabled, setSearchEnabled] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(true);

  const timersRef = useRef<ReturnType<typeof setTimeout>[]>([]);
  const stopRef = useRef(false);

  const clearTimers = () => {
    timersRef.current.forEach(clearTimeout);
    timersRef.current = [];
  };

  const activeThread = threads.find((t) => t.id === activeThreadId) ?? null;

  const newChat = useCallback(() => {
    clearTimers();
    stopRef.current = true;
    setThinking(false);
    setThinkingStep(0);
    setActiveThreadId(null);
    setInput('');
  }, []);

  const selectThread = useCallback((id: string) => {
    clearTimers();
    stopRef.current = true;
    setThinking(false);
    setThinkingStep(0);
    setActiveThreadId(id);
  }, []);

  const deleteThread = useCallback(
    (id: string) => {
      setThreads((prev) => prev.filter((t) => t.id !== id));
      if (activeThreadId === id) {
        clearTimers();
        stopRef.current = true;
        setThinking(false);
        setActiveThreadId(null);
      }
    },
    [activeThreadId]
  );

  const runThinking = useCallback(
    (threadId: string, userMsg: ChatMessage) => {
      stopRef.current = false;
      setThinking(true);
      setThinkingStep(0);

      const steps = 4;
      const stepDelay = deepThink ? 900 : 500;

      for (let i = 0; i < steps; i++) {
        const timer = setTimeout(() => {
          if (stopRef.current) return;
          setThinkingStep(i);
        }, i * stepDelay);
        timersRef.current.push(timer);
      }

      const replyTimer = setTimeout(() => {
        if (stopRef.current) return;
        setThinking(false);

        const reply = SAMPLE_REPLIES[Math.floor(Math.random() * SAMPLE_REPLIES.length)];
        const assistantMsg: ChatMessage = {
          id: uid(),
          role: 'assistant',
          content: reply,
          thinking: deepThink,
          timestamp: Date.now(),
        };

        setThreads((prev) =>
          prev.map((t) =>
            t.id === threadId
              ? {
                  ...t,
                  messages: [...t.messages, assistantMsg],
                  updatedAt: Date.now(),
                }
              : t
          )
        );
      }, steps * stepDelay + 400);
      timersRef.current.push(replyTimer);

      // reference userMsg to satisfy linter — it's part of the flow context
      void userMsg;
    },
    [deepThink]
  );

  const sendMessage = useCallback(() => {
    const text = input.trim();
    if (!text || thinking) return;

    const userMsg: ChatMessage = {
      id: uid(),
      role: 'user',
      content: text,
      timestamp: Date.now(),
    };

    let threadId = activeThreadId;

    if (!threadId) {
      threadId = uid();
      const newThread: ChatThread = {
        id: threadId,
        title: text.length > 40 ? text.slice(0, 40) + '…' : text,
        messages: [userMsg],
        createdAt: Date.now(),
        updatedAt: Date.now(),
      };
      setThreads((prev) => [newThread, ...prev]);
      setActiveThreadId(threadId);
    } else {
      setThreads((prev) =>
        prev.map((t) =>
          t.id === threadId
            ? {
                ...t,
                messages: [...t.messages, userMsg],
                updatedAt: Date.now(),
              }
            : t
        )
      );
    }

    setInput('');
    runThinking(threadId, userMsg);
  }, [input, thinking, activeThreadId, runThinking]);

  const stopGeneration = useCallback(() => {
    stopRef.current = true;
    clearTimers();
    setThinking(false);
  }, []);

  const regenerate = useCallback(() => {
    if (!activeThread || thinking) return;
    // Remove last assistant message and re-run
    const lastUserIdx = [...activeThread.messages].reverse().findIndex((m) => m.role === 'user');
    if (lastUserIdx === -1) return;
    const cutIndex = activeThread.messages.length - 1 - lastUserIdx;
    const trimmed = activeThread.messages.slice(0, cutIndex + 1);
    const lastUser = trimmed[trimmed.length - 1];

    setThreads((prev) =>
      prev.map((t) => (t.id === activeThread.id ? { ...t, messages: trimmed } : t))
    );
    runThinking(activeThread.id, lastUser);
  }, [activeThread, thinking, runThinking]);

  const messages = activeThread?.messages ?? [];

  return (
    <div className="flex h-screen w-full overflow-hidden bg-white text-gray-900">
      {/* Sidebar */}
      <div
        className={`transition-all duration-300 ease-in-out ${
          sidebarOpen ? 'w-[280px]' : 'w-0'
        } overflow-hidden`}
      >
        {sidebarOpen && (
          <Sidebar
            threads={threads}
            activeThreadId={activeThreadId}
            onNewChat={newChat}
            onSelectThread={selectThread}
            onDeleteThread={deleteThread}
            onClose={() => setSidebarOpen(false)}
          />
        )}
      </div>

      {/* Main area */}
      <div className="flex flex-1 flex-col min-w-0">
        {/* Top bar */}
        <header className="flex items-center justify-between px-4 py-3 border-b border-gray-100">
          <div className="flex items-center gap-2">
            {!sidebarOpen && (
              <button
                onClick={() => setSidebarOpen(true)}
                className="rounded-md p-1.5 text-gray-500 hover:bg-gray-100 transition-colors"
                aria-label="Open sidebar"
              >
                <PanelLeftOpen size={20} />
              </button>
            )}
            <span className="text-sm font-medium text-gray-700">
              DeepSeek Chat
            </span>
          </div>
          <button
            onClick={newChat}
            className="rounded-md p-1.5 text-gray-500 hover:bg-gray-100 transition-colors"
            aria-label="New chat"
          >
            <SquarePen size={18} />
          </button>
        </header>

        {/* Content */}
        <div className="flex flex-1 flex-col overflow-hidden">
          <div className="flex-1 overflow-y-auto">
            {messages.length === 0 ? (
              <WelcomeScreen onSuggestionClick={(prompt) => setInput(prompt)} />
            ) : (
              <MessageList
                messages={messages}
                thinking={thinking}
                thinkingStep={thinkingStep}
                onRegenerate={regenerate}
              />
            )}
          </div>

          {/* Input */}
          <ChatInput
            value={input}
            onChange={setInput}
            onSend={sendMessage}
            onStop={stopGeneration}
            thinking={thinking}
            deepThink={deepThink}
            search={searchEnabled}
            onToggleDeepThink={() => setDeepThink((v) => !v)}
            onToggleSearch={() => setSearchEnabled((v) => !v)}
          />
        </div>
      </div>
    </div>
  );
}
