export interface Suggestion {
  icon: string;
  label: string;
  prompt: string;
  category: string;
}

export const suggestions: Suggestion[] = [
  {
    icon: 'Code2',
    label: 'Write code',
    prompt: 'Help me write a Python script to scrape product data from an e-commerce website',
    category: 'Code',
  },
  {
    icon: 'PenLine',
    label: 'Write copy',
    prompt: 'Write a compelling product description for a smart home security camera',
    category: 'Writing',
  },
  {
    icon: 'Lightbulb',
    label: 'Brainstorm',
    prompt: 'Give me 10 creative ideas for a mobile app that helps people reduce screen time',
    category: 'Ideas',
  },
  {
    icon: 'FileText',
    label: 'Summarize',
    prompt: 'Summarize the key principles of effective project management in bullet points',
    category: 'Analysis',
  },
];

export interface ThinkingStep {
  label: string;
  done: boolean;
}

export const thinkingSteps: ThinkingStep[] = [
  { label: 'Analyzing your request', done: false },
  { label: 'Searching through knowledge', done: false },
  { label: 'Structuring the response', done: false },
  { label: 'Generating answer', done: false },
];
