import { useRef, useEffect, type KeyboardEvent } from 'react';
import { ArrowUp, Square, Brain, Search, Paperclip } from 'lucide-react';

interface ChatInputProps {
  value: string;
  onChange: (value: string) => void;
  onSend: () => void;
  onStop: () => void;
  thinking: boolean;
  deepThink: boolean;
  search: boolean;
  onToggleDeepThink: () => void;
  onToggleSearch: () => void;
}

export default function ChatInput({
  value,
  onChange,
  onSend,
  onStop,
  thinking,
  deepThink,
  search,
  onToggleDeepThink,
  onToggleSearch,
}: ChatInputProps) {
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    const ta = textareaRef.current;
    if (!ta) return;
    ta.style.height = 'auto';
    ta.style.height = Math.min(ta.scrollHeight, 200) + 'px';
  }, [value]);

  const handleKeyDown = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      if (value.trim() && !thinking) onSend();
    }
  };

  return (
    <div className="px-4 pb-4 pt-2">
      <div className="mx-auto w-full max-w-3xl">
        <div className="rounded-2xl border border-gray-200 bg-white shadow-sm transition-shadow focus-within:border-gray-300 focus-within:shadow-md">
          <textarea
            ref={textareaRef}
            value={value}
            onChange={(e) => onChange(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Message DeepSeek"
            rows={1}
            className="block w-full resize-none bg-transparent px-4 pt-3.5 pb-2 text-sm text-gray-800 placeholder:text-gray-400 focus:outline-none"
            style={{ maxHeight: '200px' }}
          />
          <div className="flex items-center justify-between px-3 pb-2.5">
            <div className="flex items-center gap-1.5">
              <button
                className="rounded-lg p-2 text-gray-400 hover:bg-gray-100 hover:text-gray-600 transition-colors"
                aria-label="Attach file"
              >
                <Paperclip size={18} />
              </button>
              <button
                onClick={onToggleDeepThink}
                className={`flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-medium transition-all ${
                  deepThink
                    ? 'bg-blue-50 text-blue-600 ring-1 ring-blue-200'
                    : 'text-gray-500 hover:bg-gray-100'
                }`}
              >
                <Brain size={15} />
                DeepThink
              </button>
              <button
                onClick={onToggleSearch}
                className={`flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-medium transition-all ${
                  search
                    ? 'bg-blue-50 text-blue-600 ring-1 ring-blue-200'
                    : 'text-gray-500 hover:bg-gray-100'
                }`}
              >
                <Search size={15} />
                Search
              </button>
            </div>
            {thinking ? (
              <button
                onClick={onStop}
                className="flex h-8 w-8 items-center justify-center rounded-lg bg-gray-800 text-white hover:bg-gray-700 transition-colors"
                aria-label="Stop generating"
              >
                <Square size={14} fill="currentColor" />
              </button>
            ) : (
              <button
                onClick={onSend}
                disabled={!value.trim()}
                className="flex h-8 w-8 items-center justify-center rounded-lg bg-blue-500 text-white transition-all hover:bg-blue-600 disabled:bg-gray-200 disabled:text-gray-400"
                aria-label="Send message"
              >
                <ArrowUp size={18} />
              </button>
            )}
          </div>
        </div>
        <p className="mt-2 text-center text-xs text-gray-400">
          DeepSeek can make mistakes. Check important info.
        </p>
      </div>
    </div>
  );
}
