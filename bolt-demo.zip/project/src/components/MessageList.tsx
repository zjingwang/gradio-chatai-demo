import { useEffect, useRef } from 'react';
import { Brain, Search, Copy, ThumbsUp, ThumbsDown, RefreshCw } from 'lucide-react';
import type { ChatMessage } from '@/types';

interface MessageListProps {
  messages: ChatMessage[];
  thinking: boolean;
  thinkingStep: number;
  onRegenerate: () => void;
}

export default function MessageList({
  messages,
  thinking,
  thinkingStep,
  onRegenerate,
}: MessageListProps) {
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, thinking, thinkingStep]);

  const allSteps = ['Analyzing your request', 'Searching through knowledge', 'Structuring the response', 'Generating answer'];

  return (
    <div className="mx-auto w-full max-w-3xl px-4 py-6">
      {messages.map((msg) => (
        <div key={msg.id} className="mb-8">
          {msg.role === 'user' ? (
            <div className="flex justify-end">
              <div className="max-w-[80%] rounded-2xl rounded-tr-sm bg-blue-500 px-4 py-3 text-white text-sm leading-relaxed whitespace-pre-wrap">
                {msg.content}
              </div>
            </div>
          ) : (
            <div className="flex gap-3">
              <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-gradient-to-br from-blue-500 to-blue-600">
                <span className="text-sm font-bold text-white">D</span>
              </div>
              <div className="flex-1 min-w-0">
                {msg.thinking && (
                  <div className="mb-3 rounded-lg border border-gray-200 bg-gray-50/80 px-4 py-3">
                    <div className="mb-2 flex items-center gap-2 text-sm font-medium text-gray-600">
                      <Brain size={15} className="text-blue-500" />
                      DeepThink
                      <span className="ml-1 text-xs font-normal text-gray-400">
                        {thinking ? `(${thinkingStep + 1}/${allSteps.length})` : '(Done)'}
                      </span>
                    </div>
                    <div className="space-y-1.5">
                      {allSteps.map((step, i) => {
                        const isDone = !thinking || i < thinkingStep;
                        const isActive = thinking && i === thinkingStep;
                        return (
                          <div
                            key={step}
                            className={`flex items-center gap-2 text-xs transition-opacity ${
                              isDone || isActive ? 'opacity-100' : 'opacity-40'
                            }`}
                          >
                            {isDone ? (
                              <span className="text-green-500">✓</span>
                            ) : isActive ? (
                              <span className="inline-block h-3 w-3 animate-spin rounded-full border-2 border-blue-400 border-t-transparent" />
                            ) : (
                              <span className="h-3 w-3 rounded-full border border-gray-300" />
                            )}
                            <span className={isActive ? 'text-gray-700 font-medium' : 'text-gray-500'}>
                              {step}
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}
                <div className="text-sm leading-relaxed text-gray-800 whitespace-pre-wrap">
                  {msg.content}
                </div>
                {!thinking && (
                  <div className="mt-3 flex items-center gap-1 text-gray-400">
                    <button
                      onClick={onRegenerate}
                      className="rounded-md p-1.5 hover:bg-gray-100 hover:text-gray-600 transition-colors"
                      aria-label="Regenerate"
                    >
                      <RefreshCw size={15} />
                    </button>
                    <button className="rounded-md p-1.5 hover:bg-gray-100 hover:text-gray-600 transition-colors" aria-label="Copy">
                      <Copy size={15} />
                    </button>
                    <button className="rounded-md p-1.5 hover:bg-gray-100 hover:text-gray-600 transition-colors" aria-label="Good response">
                      <ThumbsUp size={15} />
                    </button>
                    <button className="rounded-md p-1.5 hover:bg-gray-100 hover:text-gray-600 transition-colors" aria-label="Bad response">
                      <ThumbsDown size={15} />
                    </button>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      ))}

      {/* Active thinking block (no assistant message yet) */}
      {thinking && !messages.some((m) => m.role === 'assistant' && m.thinking) && (
        <div className="flex gap-3">
          <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-gradient-to-br from-blue-500 to-blue-600">
            <span className="text-sm font-bold text-white">D</span>
          </div>
          <div className="flex-1">
            <div className="rounded-lg border border-gray-200 bg-gray-50/80 px-4 py-3">
              <div className="mb-2 flex items-center gap-2 text-sm font-medium text-gray-600">
                <Brain size={15} className="text-blue-500" />
                DeepThink
                <span className="ml-1 text-xs font-normal text-gray-400">
                  ({thinkingStep + 1}/{allSteps.length})
                </span>
              </div>
              <div className="space-y-1.5">
                {allSteps.map((step, i) => {
                  const isDone = i < thinkingStep;
                  const isActive = i === thinkingStep;
                  return (
                    <div
                      key={step}
                      className={`flex items-center gap-2 text-xs transition-opacity ${
                        isDone || isActive ? 'opacity-100' : 'opacity-40'
                      }`}
                    >
                      {isDone ? (
                        <span className="text-green-500">✓</span>
                      ) : isActive ? (
                        <span className="inline-block h-3 w-3 animate-spin rounded-full border-2 border-blue-400 border-t-transparent" />
                      ) : (
                        <span className="h-3 w-3 rounded-full border border-gray-300" />
                      )}
                      <span className={isActive ? 'text-gray-700 font-medium' : 'text-gray-500'}>
                        {step}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      )}

      <div ref={endRef} />
    </div>
  );
}
