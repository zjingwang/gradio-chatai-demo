import { useState } from 'react';
import {
  Plus,
  MessageSquare,
  Trash2,
  PanelLeftClose,
  Search,
  Settings,
  HelpCircle,
} from 'lucide-react';
import type { ChatThread } from '@/types';

interface SidebarProps {
  threads: ChatThread[];
  activeThreadId: string | null;
  onNewChat: () => void;
  onSelectThread: (id: string) => void;
  onDeleteThread: (id: string) => void;
  onClose: () => void;
}

function groupByDate(threads: ChatThread[]): { label: string; items: ChatThread[] }[] {
  const now = Date.now();
  const day = 86400000;
  const groups: Record<string, ChatThread[]> = {
    Today: [],
    Yesterday: [],
    'Previous 7 Days': [],
    Older: [],
  };

  for (const t of threads) {
    const age = now - t.updatedAt;
    if (age < day) groups.Today.push(t);
    else if (age < day * 2) groups.Yesterday.push(t);
    else if (age < day * 7) groups['Previous 7 Days'].push(t);
    else groups.Older.push(t);
  }

  return Object.entries(groups)
    .filter(([, items]) => items.length > 0)
    .map(([label, items]) => ({ label, items }));
}

export default function Sidebar({
  threads,
  activeThreadId,
  onNewChat,
  onSelectThread,
  onDeleteThread,
  onClose,
}: SidebarProps) {
  const [search, setSearch] = useState('');
  const filtered = search
    ? threads.filter((t) => t.title.toLowerCase().includes(search.toLowerCase()))
    : threads;
  const groups = groupByDate(filtered);

  return (
    <aside className="flex h-full w-[280px] flex-col bg-[#f7f7f8] border-r border-gray-200">
      {/* Header */}
      <div className="flex items-center justify-between px-3 py-3">
        <div className="flex items-center gap-2">
          <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-gradient-to-br from-blue-500 to-blue-600">
            <span className="text-sm font-bold text-white">D</span>
          </div>
          <span className="text-sm font-semibold text-gray-800">DeepSeek</span>
        </div>
        <button
          onClick={onClose}
          className="rounded-md p-1.5 text-gray-400 hover:bg-gray-200 hover:text-gray-600 transition-colors"
          aria-label="Close sidebar"
        >
          <PanelLeftClose size={18} />
        </button>
      </div>

      {/* New chat */}
      <div className="px-3 pb-2">
        <button
          onClick={onNewChat}
          className="flex w-full items-center gap-2 rounded-lg border border-gray-200 bg-white px-3 py-2.5 text-sm font-medium text-gray-700 shadow-sm hover:bg-gray-50 hover:border-gray-300 transition-all"
        >
          <Plus size={16} className="text-blue-500" />
          New chat
        </button>
      </div>

      {/* Search */}
      <div className="px-3 pb-2">
        <div className="relative">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search chats"
            className="w-full rounded-lg border border-gray-200 bg-white py-2 pl-9 pr-3 text-sm text-gray-700 placeholder:text-gray-400 focus:border-blue-400 focus:outline-none focus:ring-1 focus:ring-blue-400 transition-colors"
          />
        </div>
      </div>

      {/* Thread list */}
      <div className="flex-1 overflow-y-auto px-2 py-1">
        {groups.length === 0 && (
          <div className="px-3 py-8 text-center text-sm text-gray-400">
            No conversations yet
          </div>
        )}
        {groups.map((group) => (
          <div key={group.label} className="mb-3">
            <div className="px-3 py-1.5 text-xs font-medium text-gray-400">{group.label}</div>
            {group.items.map((thread) => (
              <div
                key={thread.id}
                onClick={() => onSelectThread(thread.id)}
                className={`group flex cursor-pointer items-center gap-2 rounded-lg px-3 py-2 text-sm transition-colors ${
                  activeThreadId === thread.id
                    ? 'bg-gray-200/70 text-gray-900'
                    : 'text-gray-600 hover:bg-gray-200/50'
                }`}
              >
                <MessageSquare size={15} className="shrink-0 text-gray-400" />
                <span className="flex-1 truncate">{thread.title}</span>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onDeleteThread(thread.id);
                  }}
                  className="shrink-0 rounded p-1 text-gray-300 opacity-0 group-hover:opacity-100 hover:text-gray-600 transition-all"
                  aria-label="Delete chat"
                >
                  <Trash2 size={14} />
                </button>
              </div>
            ))}
          </div>
        ))}
      </div>

      {/* Footer */}
      <div className="border-t border-gray-200 px-2 py-2">
        <button className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-sm text-gray-600 hover:bg-gray-200/50 transition-colors">
          <HelpCircle size={16} className="text-gray-400" />
          Help & FAQ
        </button>
        <button className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-sm text-gray-600 hover:bg-gray-200/50 transition-colors">
          <Settings size={16} className="text-gray-400" />
          Settings
        </button>
      </div>
    </aside>
  );
}
