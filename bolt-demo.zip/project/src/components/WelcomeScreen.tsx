import { Code2, PenLine, Lightbulb, FileText, Sparkles } from 'lucide-react';
import type { ComponentType } from 'react';
import { suggestions } from '@/data/suggestions';

const iconMap: Record<string, ComponentType<{ size?: number; className?: string }>> = {
  Code2,
  PenLine,
  Lightbulb,
  FileText,
};

interface WelcomeScreenProps {
  onSuggestionClick: (prompt: string) => void;
}

export default function WelcomeScreen({ onSuggestionClick }: WelcomeScreenProps) {
  return (
    <div className="flex flex-1 flex-col items-center justify-center px-4 py-8">
      <div className="mb-8 flex flex-col items-center text-center">
        <div className="mb-5 flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-blue-500 to-blue-600 shadow-lg shadow-blue-500/20">
          <span className="text-2xl font-bold text-white">D</span>
        </div>
        <h1 className="mb-2 text-2xl font-semibold text-gray-800">
          Hi, I'm DeepSeek
        </h1>
        <p className="text-gray-500 text-sm">
          How can I help you today?
        </p>
      </div>

      <div className="grid w-full max-w-2xl grid-cols-2 gap-3 sm:grid-cols-4">
        {suggestions.map((s) => {
          const Icon = iconMap[s.icon] ?? Sparkles;
          return (
            <button
              key={s.label}
              onClick={() => onSuggestionClick(s.prompt)}
              className="group flex flex-col items-start gap-2 rounded-xl border border-gray-200 bg-white p-4 text-left shadow-sm transition-all hover:border-blue-300 hover:shadow-md hover:-translate-y-0.5"
            >
              <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-blue-50 text-blue-500 transition-colors group-hover:bg-blue-100">
                <Icon size={18} />
              </div>
              <span className="text-sm font-medium text-gray-700">{s.label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
